package DAY4;

public class calc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pgm5 ob=new pgm5();
		int sum=ob.add(5,10);
		System.out.println("first sum ="+sum);
		float s=ob.add(2,3,4.1f);
		System.out.println("second sum is ="+s);

	}

}
