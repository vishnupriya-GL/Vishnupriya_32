package DAY6;

public class test_animal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		elephant e1 = new elephant();
		elephant e2 = new elephant();
		tiger t1 = new tiger();
		tiger t2 = new tiger();
		
		e1.lot=7;
		e1.lotusks=6;
		e1.nol=4;
		e1.age=44;
		e1.color="Red-Orange";
		e1.food="Deers";
		e1.gender="male";
		e1.name="cccc";
		e1.display();
		e1.eats();
		e1.swim();
		
		e2.lot=4;
		e2.nol=4;
		e2.lotusks=7;
		e2.age=24;
		e2.color="Red-Orange";
		e2.food="Deers";
		e2.gender="male";
		e2.name="cccc";
		e2.display();
		e2.eats();
		e2.swim();
		e2.runs();
		
		t1.loc=6;
		t1.nol=4;
		t1.loteath=6;
		t1.age=24;
		t1.color="Red-Orange";
		t1.food="Deers";
		t1.gender="male";
		t1.name="cccc";
		t1.climb();
		t1.eats();
		t1.mauls();
		t1.roar();
		
		
		t2.loc=7;
		t2.loteath=6;
		t2.nol=4;
		t2.age=24;
		t2.color="White";
		t2.food="Fishes";
		t2.gender="male";
		t2.name="ddddd";
		t2.climb();
		t2.eats();
		t2.mauls();
		t2.roar();
		t2.runs();
		

	}

}
