package DAY6;

public class student {
	public int rollno;
	public String name;
	public int m1;
	public int m2;
	public float avg;
	public void average()
	{
		avg=(float)((m1+m2)/2.0);
	}
public student(String name,int rollno,int m1,int m2)
{
	this.name=name;
	this.rollno=rollno;
	this.m1=m1;
	this.m2=m2;
	this.average();
}
}
