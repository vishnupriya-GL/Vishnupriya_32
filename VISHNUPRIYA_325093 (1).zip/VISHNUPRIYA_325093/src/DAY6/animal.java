package DAY6;

public class animal {
	int nol;
	String color;
	String food;
	String name;
	String gender;
	int age;
	
	public void eats()
	{
		System.out.println("The animl eats"+food);
		
	}
	public void walks()
	{
		System.out.println("the animal walks");
	}

	public void runs() {
		System.out.println("the animal runs\n");
	}
	
	public void display()
	{
		System.out.println(" No of legs: " +this.nol + " Skin color: "+ this.color + " Food: " + this.food + " Name: "+this.name 
				+ " Gender: " + this.gender + " Age: " + this.age );
	}

}
