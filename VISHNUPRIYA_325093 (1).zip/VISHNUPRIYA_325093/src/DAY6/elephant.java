package DAY6;

public class elephant extends animal{
	int lot;
	int lotusks;
	
	public void swim() {
		System.out.println("Elephant swims");
	}
	

	public void spraying() {
		System.out.println("Elephant sprays using trunks");
	}
	
	public void display() {
		System.out.println(" Name: "+this.name +" No of legs: " +this.nol + " Skin color: "+ this.color + " Food: " + this.food 
							+ " Gender: " + this.gender + " Age: " + this.age );
		
		System.out.println(" Length of trunk : "+ this.lot + " Length of tusks: " + this.lotusks);
	}
}
