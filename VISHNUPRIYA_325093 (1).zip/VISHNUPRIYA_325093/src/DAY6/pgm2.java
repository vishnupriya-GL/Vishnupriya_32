package DAY6;

import java.util.ArrayList;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList <String> a1=new ArrayList<String>();
		a1.add("Rakesh");
		a1.add("Himanshu");
		a1.add("Priya");
		a1.add("suresh");
		
		System.out.println("Before Insertion:");
		System.out.println(a1);
		
		a1.add(1, "vishnu");
		System.out.println("After Insertion:");
		System.out.println(a1);
		System.out.println(a1.get(2));
		System.out.println("After Removing");
		a1.remove("vishnu");
		System.out.println(a1);

	}

}
