package DAY5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import DAY3.student;



public class operations {
	public student read_excel(int n)
	{
		student s=new student();
		try {
			File f=new File("C:\\Users\\vishnupriya.jayaraj\\Desktop\\Assignment.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("sheet1");
			XSSFRow r=sh.getRow(n);
			
			XSSFCell c=r.getCell(0);
			s.rollno=(int) c.getNumericCellValue();
			
			XSSFCell c1=r.getCell(1);
			s.name= c1.getStringCellValue();
			
			XSSFCell c2=r.getCell(2);
			s.m1=(int) c2.getNumericCellValue();
			
			XSSFCell c3=r.getCell(3);
			s.m2=(int) c3.getNumericCellValue();
			
//			//XSSFCell c=r.createCell(1);
//			XSSFRow r=sh.createRow(3);
//			XSSFCell c=r.createCell(1);
//			
			
//			//writing to a file
//			c.setCellValue("selenium");
//			FileOutputStream fos= new FileOutputStream(f);
//			wb.write(fos);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;

	}
	public void write_excel(student s1,int n)
	{
		try {
			File f=new File("C:\\Users\\vishnupriya.jayaraj\\Desktop\\Assignment.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("sheet1");
			XSSFRow r=sh.getRow(n);
			XSSFCell c=r.createCell(4);
			c.setCellValue((double) s1.avg);
			FileOutputStream fos= new FileOutputStream(f);
			wb.write(fos);
			
		}
			
			 catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}

}
