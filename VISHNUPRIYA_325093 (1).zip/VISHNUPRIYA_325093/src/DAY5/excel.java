package DAY5;

import DAY3.student;

public class excel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int r1=1;
		operations op=new operations();
		//student s1=r.read_excel();
		for(int i=1;i<=2;i++)
		{
			student s=op.read_excel(i);
			s.average();
			op.write_excel(s,i);
		}
		
		
			
		
		
		//write w=new write();
		
		
		
	}

}
